package pages;

import com.github.javafaker.Faker;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;

import java.io.File;
import java.io.IOException;
import java.util.Random;

public class BasePage {

    public static WebDriver driver;
    public void clickElement(WebElement element, String log){
        element.click();
        System.out.println("Clicked element "+log);
    }

    public void takeScreenshot(String name, String yesNo) throws IOException {
        if(yesNo.equalsIgnoreCase("YES")) {
            File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(file, new File("src/test/results/screenshots/" + name + ".png"));
        }
    }
    public void scroll(String x,String y){
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor)driver;
        javascriptExecutor.executeScript("window.scrollBy("+x+","+y+")");
    }

    public String randomEmail() {
        String email;
        Random random = new Random();
        int randomEmail = random.nextInt(5000);
        email = "stjepanovic" + randomEmail + "@yahoo.com";
        return email;
    }

    Faker fakerData = new Faker();

    public String randomUser() {
        String name = String.valueOf(fakerData.name());
        System.out.println(name);
        return name;
    }
}