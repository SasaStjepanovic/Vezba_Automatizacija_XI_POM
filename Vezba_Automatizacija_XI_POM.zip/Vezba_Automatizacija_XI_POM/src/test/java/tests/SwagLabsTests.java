package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LogoutPage;
import pages.SwagLabsLoginPage;

import java.io.IOException;

public class SwagLabsTests extends BaseTest{

    @BeforeMethod
    public void setup() throws Exception {
        init();
        driver.get("https://www.saucedemo.com/");

    }

    @AfterMethod
    public void tearDown() throws IOException {
        quit();
    }

    @Test
    public void swagLabsLogValid() throws IOException, InterruptedException {
        SwagLabsLoginPage swasg = new SwagLabsLoginPage(driver);
        swasg.login("standard_user","secret_sauce", "positive",
                "Epic sadface: Username and password do not match any user in this service", "https://www.saucedemo.com/inventory.html");

        LogoutPage lp = new LogoutPage(driver);
        lp.logout();

    }

    @Test
    public void swagLabsLoginInvalid() throws IOException, InterruptedException {
        SwagLabsLoginPage swasg = new SwagLabsLoginPage(driver);
        swasg.login("invalid","secret_sauce", "negative",
                "Epic sadface: Username and password do not match any user in this service", "https://www.saucedemo.com/inventory.html");

    }

}