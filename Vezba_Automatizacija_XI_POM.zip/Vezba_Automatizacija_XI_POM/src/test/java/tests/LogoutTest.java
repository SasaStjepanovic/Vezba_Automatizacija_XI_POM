package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.BasePage;
import pages.LogoutPage;
import pages.SwagLabsLoginPage;

import java.io.IOException;

public class LogoutTest extends BaseTest{

    @BeforeMethod
    public void setup() throws Exception {
        init();
        driver.get("https://www.saucedemo.com/");
        SwagLabsLoginPage swagPage = new SwagLabsLoginPage(driver);
        swagPage.login("standard_user","secret_sauce", "positive", "", "https://www.saucedemo.com/inventory.html");
    }

    @AfterMethod
    public void tearDown() throws IOException{
        BasePage bp = new BasePage();
        bp.takeScreenshot("SCREENSHOT_1", "YES");
        quit();
    }

    @Test
    public void logout() {
        LogoutPage logpage = new LogoutPage(driver);
        logpage.logout();

    }
}
