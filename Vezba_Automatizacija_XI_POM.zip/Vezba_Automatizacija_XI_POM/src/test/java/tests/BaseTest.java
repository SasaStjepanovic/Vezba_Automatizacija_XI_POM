package tests;

import org.openqa.selenium.WebDriver;
import pages.BasePage;
import selenium.DriverManager;
import selenium.DriverManagerFactory;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class BaseTest extends BasePage {

    WebDriver driver;
    DriverManager driverManager;


    public void init() throws Exception {
        driverManager = DriverManagerFactory.geDriverManager("CHROME");
        driver = driverManager.getWebDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    public void quit() {
        driverManager.quitWebDriver();
    }


}