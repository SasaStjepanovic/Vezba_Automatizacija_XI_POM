package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class InventoryPage extends BasePage {

    public InventoryPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    @FindBy(css = "a#item_4_title_link")
    WebElement item4_Backpack;

    @FindBy(css = "a#item_1_title_link")
    WebElement item_1_BoltTShirt;

    @FindBy(css = "a#item_2_title_link")
    WebElement item_2_Onesei;

    @FindBy(xpath = "//div[@class='inventory_list']/div[2]/div[2]//a")
    WebElement item_0_BikeLight;

    @FindBy(xpath = "//div[@class='inventory_list']/div[4]/div[2]//a")
    WebElement item_5_Jacket;

    @FindBy(xpath = "//div[@class='inventory_list']/div[6]/div[2]//a")
    WebElement item_3_TshirtRed;

    public void checkTitleOfSixtems(){
        String actualTitle1 = item4_Backpack.getText();
        String expectedTitle1 = "Sauce Labs Backpack";
        Assert.assertEquals(actualTitle1, expectedTitle1);

        String actualTitle2 = item_1_BoltTShirt.getText();
        String expectedTitle2 = "Sauce Labs Bolt T-Shirt";
        Assert.assertEquals(actualTitle2, expectedTitle2);

        String actualTitle3 = item_2_Onesei.getText();
        String expectedTitle3 = "Sauce Labs Onesie";
        Assert.assertEquals(actualTitle3, expectedTitle3);

        String actualTitle4 = item_0_BikeLight.getText();
        String expectedTitle4 = "Sauce Labs Bike Light";
        Assert.assertEquals(actualTitle4, expectedTitle4);

        String actualTitle5 = item_5_Jacket.getText();
        String expectedTitle5 = "Sauce Labs Fleece Jacket";
        Assert.assertEquals(actualTitle5, expectedTitle5);

        String actualTitle6 = item_3_TshirtRed.getText();
        String expectedTitle6 = "Test.allTheThings() T-Shirt (Red)";
        Assert.assertEquals(actualTitle6, expectedTitle6);
    }



}
