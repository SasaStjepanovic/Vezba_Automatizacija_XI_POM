package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class SwagLabsLoginPage extends BasePage{

    WebDriver driver;

    public SwagLabsLoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "#user-name")
    WebElement username;
    @FindBy(css = "#password")
    WebElement password;
    @FindBy(css = "#login-button")
    WebElement loginButton;

    public void enterUsernameRandom(){
        username.sendKeys(randomUser());
    }

    public void enterUsername(String value){
        username.sendKeys(value);
    }

    public void enterPassword(String value){
        password.sendKeys(value);
    }

    public void clickLoginButton(){
        clickElement(loginButton, "Login button");
    }

    public void login(String username, String password, String testType, String errorMessage, String expectedFilterURL) throws InterruptedException {
        if (username.equals("standard_user")){
            enterUsername(username);
        } else {
            enterUsernameRandom();
            Thread.sleep(2000);
        }
        enterPassword(password);
        clickLoginButton();

        if (testType.equals("positive")) {
            Assert.assertTrue(driver.getCurrentUrl().contains(expectedFilterURL), driver.getCurrentUrl());
        } else {
            Assert.assertEquals(driver.findElement(By.xpath("//form//h3")).getText(), errorMessage, "Something went wrong");
        }
    }

//    public void login(String username, String password){
//        enterUsername(username);
//        enterPassword(password);
//        clickLoginButton();
//    }

}