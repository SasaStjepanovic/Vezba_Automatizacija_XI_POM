package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.BasePage;
import pages.InventoryPage;
import pages.SwagLabsLoginPage;

import java.io.IOException;

public class InventoryTest extends BaseTest{

    @BeforeMethod
    public void setup() throws Exception {
        init();
        driver.get("https://www.saucedemo.com/");
        SwagLabsLoginPage swagPage = new SwagLabsLoginPage(driver);
        swagPage.login("standard_user","secret_sauce", "positive", "", "https://www.saucedemo.com/inventory.html");
    }

    @AfterMethod
    public void tearDown() throws IOException
    {
        BasePage bp = new BasePage();
        bp.takeScreenshot("SCREENSHOT_1", "YES");
        quit();
    }

    @Test
    public void checkInventoryPageSixItems() throws InterruptedException {
        InventoryPage ip = new InventoryPage(driver);
        ip.checkTitleOfSixtems();
        BasePage bp = new BasePage();
        try{
            bp.scroll("0","2000");
            Thread.sleep(2000);
        }
        catch (NullPointerException e){
            System.out.println("null exc ponovoovov");
        }


    }
}
