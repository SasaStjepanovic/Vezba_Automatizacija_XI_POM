package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

    public class LogoutPage extends BasePage {
        WebDriver driver;

        public LogoutPage(WebDriver driver) {
            this.driver = driver;
            PageFactory.initElements(driver, this);
        }

        @FindBy(css = "#react-burger-menu-btn")
        WebElement dropDownMenu;

        @FindBy(css = "#logout_sidebar_link")
        WebElement logutButton;


        public void logout(){
            clickElement(dropDownMenu, "dropDpwnMenu");
            clickElement(logutButton, "logoutButton");

        }
    }


